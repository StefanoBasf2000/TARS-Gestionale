
document.addEventListener("DOMContentLoaded", function () {
    const bot = document.createElement("div");
    bot.style.position = "fixed";
    bot.style.bottom = "20px";
    bot.style.right = "20px";
    bot.style.width = "50px";
    bot.style.height = "50px";
    bot.style.background = "url('https://cdn-icons-png.flaticon.com/512/4712/4712027.png') no-repeat center center / cover";
    bot.style.borderRadius = "50%";
    bot.style.cursor = "pointer";
    bot.title = "Hai bisogno di aiuto?";
    bot.addEventListener("click", () => alert("Ciao! Come posso aiutarti?"));
    document.body.appendChild(bot);
});
